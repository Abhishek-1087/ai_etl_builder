{{ config(materialized='table') }}

SELECT 
    p.CATEGORY,
    p.PRODUCT_NAME,
    COUNT(oi.ORDER_ITEM_ID) as QUANTITY_ORDERED,
    SUM(oi.QUANTITY * oi.UNIT_PRICE) as TOTAL_AMOUNT
FROM 
    {{ ref('stg_product') }} as {{ ref('stg_product') }}
JOIN 
    {{ ref('stg_order_item') }} as {{ ref('stg_order_item') }}
ON 
    p.PRODUCT_ID = oi.PRODUCT_ID
GROUP BY 
    p.CATEGORY,
    p.PRODUCT_NAME
ORDER BY 
    QUANTITY_ORDERED DESC,
    TOTAL_AMOUNT DESC;