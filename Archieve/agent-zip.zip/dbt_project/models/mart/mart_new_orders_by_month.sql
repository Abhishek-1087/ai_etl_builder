{{ config(materialized='table') }}

SELECT 
    to_char(order_date, 'YYYY-MM') as order_month,
    COUNT(*) as total_new_orders
FROM 
    {{ ref('stg_order_detail') }} as sod
JOIN 
    {{ ref('stg_order_item') }} as sio
ON 
    sod.order_id = sio.order_id
JOIN 
    {{ ref('stg_product') }} as sp
ON 
    sio.product_id = sp.product_id
WHERE 
    sod.status = 'new'
GROUP BY 
    1
ORDER BY 
    1;