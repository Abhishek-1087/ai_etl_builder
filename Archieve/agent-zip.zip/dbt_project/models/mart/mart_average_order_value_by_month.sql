{{ config(materialized='table') }}

SELECT 
    EXTRACT(MONTH FROM order_date) AS order_month,
    EXTRACT(YEAR FROM order_date) AS order_year,
    AVG(total_amount) AS average_order_value
FROM 
    {{ ref('stg_order_detail') }} AS od
JOIN 
    {{ ref('stg_order_item') }} AS oi
ON 
    od.order_id = oi.order_id
JOIN 
    {{ ref('stg_product') }} AS p
ON 
    oi.product_id = p.product_id
GROUP BY 
    order_year,
    order_month