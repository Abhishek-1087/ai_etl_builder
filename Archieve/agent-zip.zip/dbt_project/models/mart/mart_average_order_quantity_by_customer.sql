{{ config(materialized='table') }}

SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.city,
    c.signup_date,
    o.order_id,
    o.order_date,
    o.status,
    o.total_amount,
    i.product_id,
    i.quantity,
    i.unit_price,
    p.product_name,
    p.category,
    p.price,
    SUM(i.quantity) AS average_order_quantity
FROM 
    {{ ref('stg_customer') }} c
JOIN 
    {{ ref('stg_order_detail') }} o ON c.customer_id = o.customer_id
JOIN 
    {{ ref('stg_order_item') }} i ON o.order_id = i.order_id
JOIN 
    {{ ref('stg_product') }} p ON i.product_id = p.product_id
GROUP BY 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.city,
    c.signup_date,
    o.order_id,
    o.order_date,
    o.status,
    o.total_amount,
    i.product_id,
    i.quantity,
    i.unit_price,
    p.product_name,
    p.category,
    p.price