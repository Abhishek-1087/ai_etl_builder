{{ config(materialized='table') }}

SELECT 
    COALESCE(c.customer_id, od.customer_id) AS customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.city,
    c.signup_date,
    od.order_id,
    od.order_date,
    od.status,
    od.total_amount,
    SUM(oi.quantity * oi.unit_price) AS average_order_value
FROM {{ ref('stg_customer') }} c
JOIN {{ ref('stg_order_detail') }} od
ON 
    c.customer_id = od.customer_id
JOIN {{ ref('stg_order_item') }} oi
ON 
    od.order_id = oi.order_id
JOIN {{ ref('stg_product') }} p
ON 
    oi.product_id = p.product_id
GROUP BY 
    customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.city,
    c.signup_date,
    od.order_id,
    od.order_date,
    od.status,
    od.total_amount