{{ config(materialized='table') }}

SELECT 
    YEAR(od.ORDER_DATE) AS YEAR,
    SUM(oi.UNIT_PRICE * oi.QUANTITY) AS AVERAGE_ORDER_VALUE
FROM 
    {{ ref('stg_order_item') }} AS {{ ref('stg_order_item') }}
JOIN 
    {{ ref('stg_order_detail') }} AS {{ ref('stg_order_detail') }}
ON 
    oi.ORDER_ID = od.ORDER_ID
JOIN 
    {{ ref('stg_customer') }} AS {{ ref('stg_customer') }}
ON 
    od.CUSTOMER_ID = c.CUSTOMER_ID
GROUP BY 
    YEAR(od.ORDER_DATE)