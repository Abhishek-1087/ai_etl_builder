{{ config(materialized='table') }}

SELECT
    c.CITY,
    COUNT(DISTINCT co.CUSTOMER_ID) AS total_customers
FROM
    {{ ref('stg_customer') }} c
LEFT JOIN
    {{ ref('stg_order_detail') }} od
ON
    c.CUSTOMER_ID = od.CUSTOMER_ID
LEFT JOIN
    {{ ref('stg_order_item') }} oi
ON
    od.ORDER_ID = oi.ORDER_ID
LEFT JOIN
    {{ ref('stg_product') }} p
ON
    oi.PRODUCT_ID = p.PRODUCT_ID
LEFT JOIN
    {{ ref('stg_customer') }} co
ON
    co.CUSTOMER_ID = oi.CUSTOMER_ID
GROUP BY
    c.CITY