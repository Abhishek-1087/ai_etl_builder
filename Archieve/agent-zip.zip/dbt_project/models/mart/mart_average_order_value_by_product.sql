{{ config(materialized='table') }}

SELECT 
    p.product_id AS product_id,
    p.product_name AS product_name,
    p.category AS category,
    p.price AS price,
    SUM(oi.quantity * oi.unit_price) AS average_order_value
FROM 
    {{ ref('stg_product') }} AS {{ ref('stg_product') }}
JOIN 
    {{ ref('stg_order_item') }} AS {{ ref('stg_order_item') }}
ON 
    p.product_id = oi.product_id
GROUP BY 
    product_id,
    product_name,
    category,
    price