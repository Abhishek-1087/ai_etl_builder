{{ config(materialized='table') }}

SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.city,
    c.signup_date,
    o.order_id,
    o.order_date,
    o.status,
    o.total_amount,
    p.product_id,
    p.product_name,
    p.category,
    p.price,
    oi.quantity,
    oi.unit_price
FROM 
    {{ ref('stg_customer') }} c
JOIN 
    {{ ref('stg_order_detail') }} o ON c.customer_id = o.customer_id
JOIN 
    {{ ref('stg_order_item') }} oi ON o.order_id = oi.order_id
JOIN 
    {{ ref('stg_product') }} p ON oi.product_id = p.product_id
GROUP BY 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.city,
    c.signup_date,
    o.order_id,
    o.order_date,
    o.status,
    o.total_amount,
    p.product_id,
    p.product_name,
    p.category,
    p.price,
    oi.quantity,
    oi.unit_price