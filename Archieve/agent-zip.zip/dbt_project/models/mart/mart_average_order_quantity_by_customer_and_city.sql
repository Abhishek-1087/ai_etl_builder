{{ config(materialized='table') }}

SELECT 
    c.customer_id,
    c.city,
    COUNT(oi.order_item_id) AS average_order_quantity
FROM 
    {{ ref('stg_customer') }} c
JOIN 
    {{ ref('stg_order_item') }} oi
ON 
    c.customer_id = oi.customer_id
JOIN 
    {{ ref('stg_order_detail') }} od
ON 
    oi.order_id = od.order_id
JOIN 
    {{ ref('stg_product') }} p
ON 
    oi.product_id = p.product_id
GROUP BY 
    c.customer_id,
    c.city