{{ config(materialized='table') }}

SELECT 
    c.customer_id,
    c.city,
    SUM(o.total_amount) as average_order_value
FROM 
    {{ ref('stg_customer') }} c
JOIN 
    {{ ref('stg_order_detail') }} o ON c.customer_id = o.customer_id
JOIN 
    {{ ref('stg_order_item') }} oi ON o.order_id = oi.order_id
JOIN 
    {{ ref('stg_product') }} p ON oi.product_id = p.product_id
GROUP BY 
    c.customer_id, c.city;