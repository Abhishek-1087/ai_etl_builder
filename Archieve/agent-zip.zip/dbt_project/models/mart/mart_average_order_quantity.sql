{{ config(materialized='table') }}

SELECT 
    oi.order_id AS order_id,
    p.product_name AS product_name,
    oi.quantity AS average_order_quantity
FROM 
    {{ ref('stg_order_item') }} AS {{ ref('stg_order_item') }}
JOIN 
    {{ ref('stg_product') }} AS {{ ref('stg_product') }}
ON 
    p.product_id = oi.product_id
GROUP BY 
    oi.order_id,
    p.product_name