{{ config(materialized='table') }}

SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.city,
    c.signup_date,
    SUM(o.total_amount) as total_order_value
FROM 
    {{ ref('stg_customer') }} c
JOIN 
    {{ ref('stg_order_detail') }} o ON c.customer_id = o.customer_id
JOIN 
    {{ ref('stg_order_item') }} oi ON o.order_id = oi.order_id
JOIN 
    {{ ref('stg_product') }} p ON oi.product_id = p.product_id
GROUP BY 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.city,
    c.signup_date;