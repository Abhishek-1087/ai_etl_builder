{{ config(materialized='table') }}

SELECT 
    c.CITY,
    COUNT(o.ORDER_ID) AS total_orders
FROM 
    {{ ref('stg_customer') }} c
JOIN 
    {{ ref('stg_order_detail') }} o ON c.CUSTOMER_ID = o.CUSTOMER_ID
GROUP BY 
    c.CITY