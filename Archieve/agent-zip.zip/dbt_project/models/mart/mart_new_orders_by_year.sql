{{ config(materialized='table') }}

SELECT 
    YEAR(od.ORDER_DATE) AS ORDER_YEAR,
    COUNT(od.ORDER_ID) AS TOTAL_ORDERS,
    COUNT(DISTINCT oi.PRODUCT_ID) AS UNIQUE_PRODUCTS_ORDERED,
    SUM(oi.QUANTITY) AS TOTAL_QUANTITY_ORDERED,
    SUM(oi.UNIT_PRICE * oi.QUANTITY) AS TOTAL_AMOUNT
FROM 
    {{ ref('stg_order_detail') }} AS {{ ref('stg_order_detail') }}
JOIN 
    {{ ref('stg_order_item') }} AS {{ ref('stg_order_item') }}
ON 
    od.ORDER_ID = oi.ORDER_ID
JOIN 
    {{ ref('stg_product') }} AS {{ ref('stg_product') }}
ON 
    oi.PRODUCT_ID = p.PRODUCT_ID
GROUP BY 
    ORDER_YEAR