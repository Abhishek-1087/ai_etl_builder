{{ config(materialized='table') }}

SELECT 
    p.product_id AS product_id,
    p.product_name AS product_name,
    p.category AS category,
    p.price AS price,
    oi.order_id AS order_id,
    oi.product_id AS product_id,
    oi.quantity AS quantity,
    oi.unit_price AS unit_price,
    SUM(oi.quantity * oi.unit_price) AS total_amount
FROM 
    {{ ref('stg_product') }} AS p
JOIN 
    {{ ref('stg_order_item') }} AS oi
ON 
    p.product_id = oi.product_id
GROUP BY 
    p.product_id,
    p.product_name,
    p.category,
    p.price,
    oi.order_id,
    oi.product_id,
    oi.quantity,
    oi.unit_price
ORDER BY 
    total_amount DESC
LIMIT 1