{{ config(materialized='table') }}

SELECT 
    c.CITY,
    SUM(o.TOTAL_AMOUNT) AS total_income_by_city
FROM 
    {{ ref('stg_order_detail') }} o
JOIN 
    {{ ref('stg_customer') }} c
ON 
    o.CUSTOMER_ID = c.CUSTOMER_ID
GROUP BY 
    c.CITY