
        {{ config(materialized='view') }}
SELECT
  {{ replace_null('PRODUCT_ID', 'NUMBER') }} AS PRODUCT_ID,
  {{ replace_null('PRODUCT_NAME', 'TEXT') }} AS PRODUCT_NAME,
  {{ replace_null('CATEGORY', 'TEXT') }} AS CATEGORY,
  {{ replace_null('PRICE', 'NUMBER') }} AS PRICE
FROM {{ source('raw','PRODUCT') }}
