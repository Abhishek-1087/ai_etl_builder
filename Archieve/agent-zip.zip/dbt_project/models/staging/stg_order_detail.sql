
        {{ config(materialized='view') }}
SELECT
  {{ replace_null('ORDER_ID', 'NUMBER') }} AS ORDER_ID,
  {{ replace_null('CUSTOMER_ID', 'NUMBER') }} AS CUSTOMER_ID,
  {{ replace_null('ORDER_DATE', 'DATE') }} AS ORDER_DATE,
  {{ replace_null('STATUS', 'TEXT') }} AS STATUS,
  {{ replace_null('TOTAL_AMOUNT', 'NUMBER') }} AS TOTAL_AMOUNT
FROM {{ source('raw','ORDER_DETAIL') }}
